@echo off
java -jar "%~dp0Dicom3DViewer-portable.jar"

